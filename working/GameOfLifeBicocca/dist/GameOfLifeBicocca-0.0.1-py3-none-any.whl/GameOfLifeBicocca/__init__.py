from .GameOfLifeBicocca import *
